
import React, { useState, useMemo } from 'react';
import { Section, NodeStatus, User, Transaction } from './types';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import TransactionForm from './components/TransactionForm';
import BlockchainView from './components/BlockchainView';
import NetworkMonitor from './components/NetworkMonitor';
import Navbar from './components/Navbar';

// Data parsed from provided text files
const INITIAL_USERS: (User & { password?: string })[] = [
  { username: 'XYZ', balance: 495000, walletAddress: '1FiDsYSWMduic9MrB1jV7YX5daknY2p5e4', password: '123', creditCard: { number: '3715 9363 8888 839', expiry: '10/2026' } },
  { username: 'Alice', balance: 12374100100100100000, walletAddress: '14Z7C4qwoehArTwEF6siYkN7bUzNjgHQP5', password: 'password1', creditCard: { number: '5277 7297 5705 2674', expiry: '2/2025' } },
  { username: 'Bob', balance: 10560100100, walletAddress: '1N1pLQWMTn6AtVkLUVznPqL58cwc4dcP7P', password: 'password2', creditCard: { number: '4196 5347 4859 1249', expiry: '7/2026' } },
  { username: 'Adam', balance: 49876641, walletAddress: '1ATEUoZDxenjSYsxQrTNdsxxZhS1177xxg', password: 'Mine23', creditCard: { number: '4715 9363 7777 839', expiry: '10/2022' } },
  { username: 'Ayat', balance: 11320, walletAddress: '1EvLw5d4vwVmah9EHbE8a9m1yrFwV94TP6', password: 'Ayat55', creditCard: { number: '5277 7297 5705 2674', expiry: '2/2020' } },
];

const INITIAL_HISTORY: Transaction[] = [
  { id: 'tx-1', sender: 'Bob', recipient: 'XYZ', amount: 20, accountType: 'current', timestamp: '2025-04-10T08:32:57', nodeId: 'Computer-1', hash: 'hash_01', status: 'CONSENSUS_REACHED', signatures: ['Computer-1', 'Computer-2', 'Computer-3'] },
  { id: 'tx-2', sender: 'Bob', recipient: 'Alice', amount: 10, accountType: 'savings', timestamp: '2025-04-10T08:50:34', nodeId: 'Computer-2', hash: 'hash_02', status: 'CONSENSUS_REACHED', signatures: ['Computer-1', 'Computer-2', 'Computer-5'] },
  { id: 'tx-3', sender: 'XYZ', recipient: 'Alice', amount: 100, accountType: 'savings', timestamp: '2025-04-10T09:01:24', nodeId: 'Computer-1', hash: 'hash_03', status: 'CONSENSUS_REACHED', signatures: ['Computer-1', 'Computer-3', 'Computer-4'] },
  { id: 'tx-4', sender: 'XYZ', recipient: 'Alice', amount: 100, accountType: 'savings', timestamp: '2025-04-10T09:44:35', nodeId: 'Computer-3', hash: 'hash_04', status: 'CONSENSUS_REACHED', signatures: ['Computer-1', 'Computer-2', 'Computer-3'] },
  { id: 'tx-5', sender: 'XYZ', recipient: 'Alice', amount: 100, accountType: 'savings', timestamp: '2025-04-10T10:45:54', nodeId: 'Computer-4', hash: 'hash_05', status: 'CONSENSUS_REACHED', signatures: ['Computer-2', 'Computer-4', 'Computer-5'] },
  { id: 'tx-6', sender: 'XYZ', recipient: 'Bob', amount: 100, accountType: 'savings', timestamp: '2025-04-10T10:49:57', nodeId: 'Computer-5', hash: 'hash_06', status: 'CONSENSUS_REACHED', signatures: ['Computer-1', 'Computer-4', 'Computer-5'] },
];

const App: React.FC = () => {
  const [currentSection, setCurrentSection] = useState<Section>(Section.LOGIN);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeNodeId, setActiveNodeId] = useState<number>(1);
  
  const [nodes, setNodes] = useState<NodeStatus[]>(() => 
    Array.from({ length: 5 }, (_, i) => ({
      id: i + 1,
      name: `Computer-${i + 1}`,
      port: 3000 + i + 1,
      isOnline: true,
      transactions: [...INITIAL_HISTORY],
      users: INITIAL_USERS.map(({password, ...u}) => u),
      pendingQueue: []
    }))
  );

  const activeNode = useMemo(() => 
    nodes.find(n => n.id === activeNodeId) || nodes[0], 
  [nodes, activeNodeId]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setCurrentSection(Section.DASHBOARD);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentSection(Section.LOGIN);
  };

  const processTransaction = async (txData: { recipient: string; amount: number; accountType: string }) => {
    if (!currentUser) return { success: false, message: "No active user" };

    const newTx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      sender: currentUser.username,
      recipient: txData.recipient,
      amount: txData.amount,
      accountType: txData.accountType,
      timestamp: new Date().toLocaleString(),
      nodeId: activeNode.name,
      hash: '0000' + Math.random().toString(16).substr(2, 32),
      status: 'PENDING',
      signatures: [activeNode.name]
    };

    setNodes(prevNodes => prevNodes.map(node => 
      node.isOnline ? { ...node, pendingQueue: [...node.pendingQueue, newTx] } : node
    ));

    await new Promise(resolve => setTimeout(resolve, 1500));

    const onlineCount = nodes.filter(n => n.isOnline).length;
    const requiredApprovals = 3;

    if (onlineCount >= requiredApprovals) {
      setNodes(prevNodes => prevNodes.map(node => {
        if (!node.isOnline) return node;

        const updatedUsers = node.users.map(u => {
          if (u.username === newTx.sender) return { ...u, balance: u.balance - newTx.amount };
          if (u.username === newTx.recipient) return { ...u, balance: u.balance + newTx.amount };
          return u;
        });

        const completedTx: Transaction = { 
          ...newTx, 
          status: 'CONSENSUS_REACHED', 
          signatures: prevNodes.filter(n => n.isOnline).map(n => n.name) 
        };

        return {
          ...node,
          transactions: [completedTx, ...node.transactions],
          pendingQueue: node.pendingQueue.filter(t => t.id !== newTx.id),
          users: updatedUsers
        };
      }));
      
      setCurrentUser(prev => prev ? { ...prev, balance: prev.balance - newTx.amount } : null);
      return { success: true, message: `Consensus reached by ${onlineCount} nodes!` };
    } else {
      return { success: false, message: "Network consensus failed. Not enough nodes online (3 required)." };
    }
  };

  const toggleNodePower = (id: number) => {
    setNodes(prev => prev.map(n => n.id === id ? { ...n, isOnline: !n.isOnline } : n));
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-blue-600 text-white p-4 shadow-lg sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <span className="bg-white text-blue-600 rounded px-2 text-sm">ATM</span> 
            Bank Network <span className="text-blue-200 font-normal text-sm hidden sm:inline">| Cluster 5X</span>
          </h1>
          {currentUser && (
            <div className="flex items-center gap-4">
               <div className="flex bg-blue-700 rounded-lg p-1">
                 {nodes.map(node => (
                   <button
                    key={node.id}
                    onClick={() => setActiveNodeId(node.id)}
                    className={`px-3 py-1 rounded-md text-xs transition ${activeNodeId === node.id ? 'bg-white text-blue-700 shadow-sm' : 'hover:bg-blue-500'}`}
                   >
                     PC-{node.id}
                   </button>
                 ))}
               </div>
            </div>
          )}
        </div>
      </header>

      {currentUser && (
        <Navbar 
          current={currentSection} 
          onChange={setCurrentSection} 
          onLogout={handleLogout} 
        />
      )}

      <main className="container mx-auto p-4 flex-grow">
        {currentSection === Section.LOGIN && <Login onLogin={handleLogin} users={INITIAL_USERS as any} />}
        
        {currentUser && currentSection === Section.DASHBOARD && (
          <Dashboard user={currentUser} node={activeNode} />
        )}

        {currentUser && currentSection === Section.TRANSACTION && (
          <TransactionForm 
            user={currentUser} 
            node={activeNode} 
            onProcess={processTransaction} 
            users={nodes[0].users}
          />
        )}

        {currentUser && currentSection === Section.BLOCKCHAIN && (
          <BlockchainView transactions={activeNode.transactions} nodeName={activeNode.name} />
        )}

        {currentUser && currentSection === Section.NETWORK && (
          <NetworkMonitor 
            nodes={nodes} 
            onTogglePower={toggleNodePower} 
            onSwitchNode={setActiveNodeId}
            activeId={activeNodeId}
          />
        )}
      </main>

      <footer className="bg-white border-t p-4 text-center text-xs text-gray-400">
        Distributed Ledger Active • Nodes: {nodes.filter(n => n.isOnline).length}/5 Online • Secure Session
      </footer>
    </div>
  );
};

export default App;


import React from 'react';
import { Transaction } from '../types';

interface BlockchainViewProps {
  transactions: Transaction[];
  nodeName: string;
}

const BlockchainView: React.FC<BlockchainViewProps> = ({ transactions, nodeName }) => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Local Ledger: {nodeName}</h2>
        <span className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-xs font-mono">
          {transactions.length} BLOCKS
        </span>
      </div>

      {transactions.length === 0 ? (
        <div className="bg-white rounded-2xl p-20 text-center border-2 border-dashed border-gray-200">
          <div className="text-5xl mb-4">📭</div>
          <h3 className="text-lg font-medium text-gray-600">No transactions recorded yet</h3>
          <p className="text-gray-400">Ledger will update once network consensus is achieved.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {transactions.map((tx, idx) => (
            <div key={tx.id} className="bg-white rounded-xl shadow-sm border p-5 transition hover:shadow-md">
              <div className="flex flex-col md:flex-row justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-bold text-blue-600">Block #{transactions.length - idx}</span>
                    <span className="text-xs text-gray-400 font-mono">ID: {tx.id}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-12 gap-y-2 text-sm">
                    <p><span className="text-gray-500">From:</span> <span className="font-semibold">{tx.sender}</span></p>
                    <p><span className="text-gray-500">To:</span> <span className="font-semibold">{tx.recipient}</span></p>
                    <p><span className="text-gray-500">Amount:</span> <span className="font-bold text-green-600">${tx.amount.toLocaleString()}</span></p>
                    <p><span className="text-gray-500">Type:</span> <span className="capitalize">{tx.accountType}</span></p>
                  </div>
                </div>
                <div className="md:w-64 border-l md:pl-6">
                  <div className="text-xs text-gray-500 mb-1">HASH REFERENCE</div>
                  <div className="bg-gray-50 p-2 rounded font-mono text-[10px] break-all text-gray-600 mb-2 border">
                    {tx.hash}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-green-500"></span>
                    <span className="text-xs font-bold text-green-700 uppercase tracking-tighter">Verified by {tx.signatures.length} Nodes</span>
                  </div>
                  <div className="text-[10px] text-gray-400 mt-1 uppercase">{tx.timestamp}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BlockchainView;


import React from 'react';
import { NodeStatus } from '../types';

interface NetworkMonitorProps {
  nodes: NodeStatus[];
  onTogglePower: (id: number) => void;
  onSwitchNode: (id: number) => void;
  activeId: number;
}

const NetworkMonitor: React.FC<NetworkMonitorProps> = ({ nodes, onTogglePower, onSwitchNode, activeId }) => {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-2xl p-6 shadow-md border">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">5-PC Distributed Network</h2>
        <p className="text-gray-500 mb-8">Monitor the status of all terminal nodes in the banking cluster.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {nodes.map(node => (
            <div 
              key={node.id} 
              className={`relative rounded-2xl p-6 border-2 transition-all ${
                activeId === node.id ? 'border-blue-500 bg-blue-50 shadow-lg' : 'border-gray-100 bg-white'
              }`}
            >
              {activeId === node.id && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase">
                  Current PC
                </div>
              )}
              
              <div className="text-center mb-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-2 text-2xl transition ${
                  node.isOnline ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600 grayscale'
                }`}>
                  {node.isOnline ? '💻' : '🔌'}
                </div>
                <h3 className="font-bold text-gray-800">{node.name}</h3>
                <p className="text-xs font-mono text-gray-500">Port {node.port}</p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Status:</span>
                  <span className={`font-bold ${node.isOnline ? 'text-green-600' : 'text-red-600'}`}>
                    {node.isOnline ? 'ONLINE' : 'OFFLINE'}
                  </span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">Blocks:</span>
                  <span className="font-bold">{node.transactions.length}</span>
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <button
                  onClick={() => onSwitchNode(node.id)}
                  className={`w-full py-2 rounded-lg text-xs font-bold transition ${
                    activeId === node.id 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  Switch PC
                </button>
                <button
                  onClick={() => onTogglePower(node.id)}
                  className={`w-full py-2 rounded-lg text-xs font-bold border transition ${
                    node.isOnline 
                      ? 'border-red-200 text-red-600 hover:bg-red-50' 
                      : 'border-green-200 text-green-600 hover:bg-green-50'
                  }`}
                >
                  {node.isOnline ? 'Shut Down' : 'Power On'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl p-6 shadow-md border">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span className="text-xl">🧬</span> Consensus Visualization
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-xl border">
              <p className="text-sm font-medium mb-3">Live Network Propagation</p>
              <div className="flex justify-between items-center px-4">
                 {nodes.map((n, i) => (
                   <React.Fragment key={n.id}>
                     <div className={`w-3 h-3 rounded-full transition-colors ${n.isOnline ? 'bg-blue-500' : 'bg-red-400'}`}></div>
                     {i < nodes.length - 1 && <div className={`flex-grow h-[2px] mx-1 ${n.isOnline && nodes[i+1].isOnline ? 'bg-blue-200' : 'bg-gray-100'}`}></div>}
                   </React.Fragment>
                 ))}
              </div>
              <div className="flex justify-between mt-2 px-1">
                {nodes.map(n => <span key={n.id} className="text-[8px] text-gray-400 font-bold uppercase">{n.id}</span>)}
              </div>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed">
              In this decentralized architecture, nodes constantly cross-check ledger integrity. If a transaction occurs on PC-1, it broadcasts the payload to PC-2, 3, 4, and 5. Only when a 51% majority (at least 3 nodes) validates the hash is the block appended to all local databases.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-md border">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span className="text-xl">📊</span> Cluster Metrics
          </h3>
          <div className="space-y-5">
             <div>
               <div className="flex justify-between text-xs mb-1">
                 <span className="text-gray-500 uppercase">Network Availability</span>
                 <span className="font-bold text-blue-600">{(nodes.filter(n => n.isOnline).length / 5 * 100)}%</span>
               </div>
               <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                 <div 
                   className="bg-blue-500 h-full transition-all duration-500" 
                   style={{ width: `${(nodes.filter(n => n.isOnline).length / 5 * 100)}%` }}
                 ></div>
               </div>
             </div>
             
             <div className="flex items-start gap-3 bg-blue-50 p-4 rounded-xl border border-blue-100">
               <span className="text-2xl">🛡️</span>
               <div>
                 <h4 className="text-sm font-bold text-blue-800 mb-1">Byzantine Fault Tolerance</h4>
                 <p className="text-xs text-blue-600">The network can tolerate up to 2 offline or malicious nodes while maintaining 100% data consistency across active terminals.</p>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NetworkMonitor;

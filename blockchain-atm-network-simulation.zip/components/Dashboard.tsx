
import React from 'react';
import { User, NodeStatus } from '../types';

interface DashboardProps {
  user: User;
  node: NodeStatus;
}

const Dashboard: React.FC<DashboardProps> = ({ user, node }) => {
  // Use formatting that handles BigInt strings or large numbers gracefully
  const formattedBalance = typeof user.balance === 'number' 
    ? user.balance.toLocaleString() 
    : user.balance.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden border border-slate-700 lg:col-span-2">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-8">
            <div>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Decentralized Asset Balance</p>
              <h2 className="text-3xl md:text-5xl font-mono font-bold break-all">
                <span className="text-emerald-400 mr-2">$</span>
                {formattedBalance}
              </h2>
            </div>
            <div className="bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border border-emerald-500/30">
              Verified
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-auto">
             <div>
               <p className="text-slate-500 text-[10px] font-bold uppercase mb-1">Card Number</p>
               <p className="font-mono text-sm tracking-widest text-slate-200">{user.creditCard.number}</p>
             </div>
             <div className="text-right">
               <p className="text-slate-500 text-[10px] font-bold uppercase mb-1">Valid Thru</p>
               <p className="font-mono text-sm text-slate-200">{user.creditCard.expiry}</p>
             </div>
          </div>
        </div>
        {/* Subtle holographic effect */}
        <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-md border flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-6">
             <h3 className="text-gray-800 font-bold flex items-center gap-2">
               <span className="text-blue-500 text-xl">📡</span> PC Node Info
             </h3>
             <span className={`px-2 py-1 rounded text-[10px] font-bold ${node.isOnline ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
               {node.isOnline ? 'STABLE' : 'OFFLINE'}
             </span>
          </div>
          <div className="space-y-4 text-sm">
            <div className="flex justify-between items-center pb-2 border-b border-gray-50">
              <span className="text-gray-500">Virtual Host:</span>
              <span className="font-bold text-gray-800 uppercase text-xs">{node.name}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b border-gray-50">
              <span className="text-gray-500">Local Consensus:</span>
              <span className="font-mono bg-gray-100 px-2 py-0.5 rounded text-xs">{node.transactions.length} Blocks</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Uptime:</span>
              <span className="text-gray-800 text-xs">99.98% Simulation</span>
            </div>
          </div>
        </div>
        <div className="mt-6 flex items-center justify-center gap-2 bg-slate-50 p-3 rounded-xl border border-dashed">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-ping"></div>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">Synchronized with 4 Peers</span>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-md border lg:col-span-3">
        <div className="flex flex-col md:flex-row items-center gap-8">
          <div className="bg-slate-50 p-6 rounded-2xl border-2 border-slate-200 flex-shrink-0 shadow-inner">
             <div className="grid grid-cols-6 gap-1 w-32 h-32">
               {Array.from({length: 36}).map((_, i) => (
                 <div key={i} className={`rounded-sm ${((i * 13) % 7 > 2) ? 'bg-slate-800' : 'bg-transparent'}`}></div>
               ))}
             </div>
          </div>
          <div className="flex-grow">
            <h3 className="text-gray-800 font-bold mb-2">Primary Wallet Address</h3>
            <p className="text-xs text-gray-400 mb-4 leading-relaxed">
              This address is used to sign transactions within the 5-node cluster. Any transfer initiated requires a majority signature match from this wallet.
            </p>
            <div className="group relative">
              <div className="bg-slate-900 text-blue-400 p-4 rounded-xl font-mono text-sm break-all border border-slate-800 shadow-lg">
                {user.walletAddress}
              </div>
              <div className="absolute -top-3 -right-2 bg-blue-600 text-white text-[8px] font-bold px-2 py-1 rounded shadow-lg uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                Mainnet Node
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

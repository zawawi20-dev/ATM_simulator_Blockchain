
import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
  users: (User & { password?: string })[];
}

const Login: React.FC<LoginProps> = ({ onLogin, users }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const foundUser = users.find(u => u.username === username);
    
    if (foundUser && foundUser.password === password) {
      const { password: _, ...userWithoutPass } = foundUser;
      onLogin(userWithoutPass as User);
    } else {
      setError('Invalid username or password for this node.');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 bg-white rounded-xl shadow-2xl p-8 border border-gray-100">
      <div className="text-center mb-8">
        <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-3xl">🛡️</span>
        </div>
        <h2 className="text-2xl font-bold text-gray-800">Cluster Authentication</h2>
        <p className="text-gray-500 mt-2 text-sm">Enter your credentials to access the 5-node ATM network</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Account ID</label>
          <input
            type="text"
            className="w-full px-4 py-3 rounded-lg border bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition"
            placeholder="e.g. Alice, Bob, XYZ"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Access Key</label>
          <input
            type="password"
            className="w-full px-4 py-3 rounded-lg border bg-gray-50 focus:bg-white focus:ring-2 focus:ring-blue-500 outline-none transition"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && <p className="text-red-500 text-xs bg-red-50 p-3 rounded-lg border border-red-100">{error}</p>}
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg transition-all active:scale-95"
        >
          Secure Node Access
        </button>
      </form>
      
      <div className="mt-8 pt-6 border-t text-center">
        <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mb-3">Network Directory</p>
        <div className="flex flex-wrap justify-center gap-2">
          {users.map(u => (
            <span key={u.username} className="px-2 py-1 bg-gray-100 text-gray-500 text-[10px] rounded font-mono">
              {u.username}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Login;

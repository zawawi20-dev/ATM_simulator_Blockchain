
import React, { useState } from 'react';
import { User, NodeStatus } from '../types';

interface TransactionFormProps {
  user: User;
  node: NodeStatus;
  users: User[];
  onProcess: (data: { recipient: string; amount: number; accountType: string }) => Promise<{ success: boolean; message: string }>;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ user, node, users, onProcess }) => {
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [accountType, setAccountType] = useState('savings');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error', msg: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (amount > user.balance) {
      setFeedback({ type: 'error', msg: 'Insufficient funds for this transaction.' });
      return;
    }
    
    setLoading(true);
    setFeedback(null);
    
    const result = await onProcess({ recipient, amount, accountType });
    
    setLoading(false);
    if (result.success) {
      setFeedback({ type: 'success', msg: result.message });
      setAmount(0);
      setRecipient('');
    } else {
      setFeedback({ type: 'error', msg: result.message });
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-lg border p-8">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Initiate P2P Transfer</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Recipient Username</label>
            <select 
              className="w-full px-4 py-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              required
            >
              <option value="">Select recipient...</option>
              {users.filter(u => u.username !== user.username).map(u => (
                <option key={u.username} value={u.username}>{u.username}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Account Type</label>
            <select 
              className="w-full px-4 py-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none"
              value={accountType}
              onChange={(e) => setAccountType(e.target.value)}
            >
              <option value="savings">Savings Account</option>
              <option value="current">Current Account</option>
              <option value="business">Business Account</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Transfer Amount ($)</label>
          <div className="grid grid-cols-4 gap-2 mb-4">
            {[100, 1000, 10000, 25000].map(val => (
              <button
                key={val}
                type="button"
                onClick={() => setAmount(val)}
                className={`py-2 rounded-lg text-sm border transition ${amount === val ? 'bg-blue-600 text-white border-blue-600' : 'bg-gray-50 hover:bg-gray-100'}`}
              >
                ${val.toLocaleString()}
              </button>
            ))}
          </div>
          <input
            type="number"
            className="w-full px-4 py-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="Or enter specific amount"
            value={amount || ''}
            onChange={(e) => setAmount(Number(e.target.value))}
            min="1"
            required
          />
        </div>

        {feedback && (
          <div className={`p-4 rounded-lg flex items-start gap-3 ${feedback.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
            <span>{feedback.type === 'success' ? '✅' : '❌'}</span>
            <p className="text-sm font-medium">{feedback.msg}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg transition-all active:scale-[0.98] flex justify-center items-center gap-3 ${
            loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'
          }`}
        >
          {loading ? (
            <>
              <div className="w-5 h-5 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
              Requesting Consensus...
            </>
          ) : (
            'Broadcast Transaction'
          )}
        </button>
      </form>
      
      <div className="mt-8 bg-amber-50 rounded-lg p-4 border border-amber-200">
        <h4 className="text-amber-800 font-bold text-sm mb-1">Network Security Protocol</h4>
        <p className="text-amber-700 text-xs">
          Clicking "Broadcast" will initiate a 5-node verification process. The ledger on <strong>{node.name}</strong> will wait for digital signatures from 2 additional peer nodes before finalizing the transfer.
        </p>
      </div>
    </div>
  );
};

export default TransactionForm;


import React from 'react';
import { Section } from '../types';

interface NavbarProps {
  current: Section;
  onChange: (s: Section) => void;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ current, onChange, onLogout }) => {
  const items = [
    { id: Section.DASHBOARD, label: 'Dashboard', icon: '🏠' },
    { id: Section.TRANSACTION, label: 'Transfer', icon: '💸' },
    { id: Section.BLOCKCHAIN, label: 'Blockchain', icon: '⛓️' },
    { id: Section.NETWORK, label: 'Network', icon: '🌐' },
  ];

  return (
    <nav className="bg-white shadow-md border-b">
      <div className="container mx-auto flex overflow-x-auto no-scrollbar">
        {items.map(item => (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className={`flex items-center gap-2 px-6 py-4 border-b-2 transition whitespace-nowrap ${
              current === item.id 
                ? 'border-blue-600 text-blue-600 bg-blue-50' 
                : 'border-transparent text-gray-600 hover:bg-gray-50'
            }`}
          >
            <span>{item.icon}</span>
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
        <button
          onClick={onLogout}
          className="ml-auto px-6 py-4 text-red-600 hover:bg-red-50 font-medium transition"
        >
          Logout 👋
        </button>
      </div>
    </nav>
  );
};

export default Navbar;


export interface User {
  username: string;
  balance: number;
  walletAddress: string;
  creditCard: {
    number: string;
    expiry: string;
  };
}

export interface Transaction {
  id: string;
  sender: string;
  recipient: string;
  amount: number;
  accountType: string;
  timestamp: string;
  nodeId: string;
  hash: string;
  status: 'PENDING' | 'CONSENSUS_REACHED' | 'FAILED';
  signatures: string[];
}

export interface NodeStatus {
  id: number;
  name: string;
  port: number;
  isOnline: boolean;
  transactions: Transaction[];
  users: User[];
  pendingQueue: Transaction[];
}

export enum Section {
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  TRANSACTION = 'TRANSACTION',
  BLOCKCHAIN = 'BLOCKCHAIN',
  NETWORK = 'NETWORK'
}
